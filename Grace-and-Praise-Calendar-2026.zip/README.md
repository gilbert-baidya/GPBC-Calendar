# Calendar 2026 - Multi-Cultural Events Calendar

A beautiful, interactive calendar application featuring Bangladeshi national events, American holidays, Christian observances, and special days like Valentine's Day, Mother's Day, and Father's Day.

## Features

### 📅 Comprehensive Event Coverage
- **Bangladeshi Events**: Independence Day, Victory Day, Pohela Boishakh, International Mother Language Day, and more
- **American Holidays**: Independence Day, Thanksgiving, Memorial Day, Labor Day, and all major US holidays
- **Christian Observances**: Easter, Christmas, Advent, Lent, and all major Christian holy days
- **Special Days**: Valentine's Day, Mother's Day, Father's Day, Earth Day, Halloween, and more

### 🎨 User Interface
- Beautiful gradient design with smooth animations
- Interactive calendar grid with color-coded events
- Month-by-month navigation
- Event filtering by category (toggle categories on/off)
- Responsive design - works on desktop, tablet, and mobile
- Today's date is highlighted

### 🔔 Reminder System
- Automatic reminders shown 2 months before each event
- View all upcoming events in a dedicated reminder modal
- Urgent reminders highlighted for events within 30 days
- Daily notification checks (with localStorage)
- Browser notification support (optional)

### 🖨️ Print & Share
- **Print**: Beautiful print-optimized layout - print any month
- **Share**: Share month's events via native share or copy to clipboard
- Export reminders to iCal format (.ics file) for importing into other calendars

### 📱 Additional Features
- Click on any event to see full details and description
- Events are organized and displayed in the sidebar
- Color-coded by category for easy identification
- Persistent filter preferences

## File Structure

```
Calendar 2026/
├── index.html          # Main HTML structure
├── styles.css          # All styling and print styles
├── events.js           # Complete events database
├── calendar.js         # Calendar rendering and navigation logic
├── reminders.js        # Reminder system and notifications
└── README.md          # This file
```

## How to Use

1. **Open the Calendar**: Simply open `index.html` in any modern web browser

2. **Navigate**: Use the "Previous" and "Next" buttons to browse months

3. **Filter Events**: Click the checkboxes to show/hide different event categories:
   - 🇧🇩 Bangladeshi events (green)
   - 🇺🇸 American events (red)
   - ✝️ Christian events (purple)
   - ❤️ Special days (pink)

4. **View Details**: Click on any event marker to see full details

5. **Check Reminders**: Click "View Reminders" to see all events coming up in the next 2 months

6. **Print**: Click "Print Calendar" to print the current month

7. **Share**: Click "Share Events" to share the month's events via text or social media

## Events Included (2026)

### Bangladeshi Events (7 events)
- International Mother Language Day (February 21)
- Bangabandhu's Birthday (March 17)
- Independence Day (March 26)
- Pohela Boishakh - Bengali New Year (April 14)
- May Day (May 1)
- National Mourning Day (August 15)
- Victory Day (December 16)

### American Events (9 events)
- New Year's Day, MLK Day, Presidents' Day
- Memorial Day, Independence Day, Labor Day
- Columbus Day, Veterans Day, Thanksgiving

### Christian Events (13 events)
- Epiphany, Ash Wednesday, Palm Sunday
- Maundy Thursday, Good Friday, Easter Sunday
- Ascension Day, Pentecost, Advent
- Christmas Eve, Christmas Day, Boxing Day

### Special Days (7 events)
- Valentine's Day, International Women's Day
- Earth Day, Mother's Day, Father's Day
- Halloween, New Year's Eve

## Technical Details

- **No Dependencies**: Pure HTML, CSS, and JavaScript - no frameworks required
- **Browser Compatibility**: Works in all modern browsers (Chrome, Firefox, Safari, Edge)
- **Responsive**: Mobile-friendly design
- **Local Storage**: Saves reminder check dates and preferences
- **Print Optimized**: Special CSS for clean printing

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Any modern browser with ES6 support

## Customization

You can easily customize the calendar by editing:
- `events.js`: Add or modify events
- `styles.css`: Change colors, fonts, or layout
- `reminders.js`: Adjust reminder timing (currently 2 months)

## Tips

1. **Bookmark**: Add to your browser bookmarks for quick access
2. **Desktop Shortcut**: Create a desktop shortcut to the HTML file
3. **Mobile**: Add to your phone's home screen for app-like experience
4. **Print**: Print each month at the start of the year for a physical calendar
5. **Reminders**: Enable browser notifications for automatic alerts

## License

Free to use and modify for personal or commercial purposes.

## Credits

Created for tracking multi-cultural events throughout 2026.

---

Enjoy your 2026 Calendar! 📅✨
