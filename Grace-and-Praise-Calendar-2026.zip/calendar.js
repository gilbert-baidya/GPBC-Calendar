// Calendar Logic
let currentMonth = 0; // January 2026
let currentYear = 2026;
let activeFilters = new Set(['bangladeshi', 'american', 'christian', 'special']);

// Initialize calendar on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeCalendar();
    setupEventListeners();
    checkAndShowReminders();
});

function initializeCalendar() {
    renderCalendar();
    renderMonthEvents();
}

function setupEventListeners() {
    // Navigation buttons
    document.getElementById('prevMonth').addEventListener('click', () => {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        renderCalendar();
        renderMonthEvents();
    });

    document.getElementById('nextMonth').addEventListener('click', () => {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        renderCalendar();
        renderMonthEvents();
    });

    // Filter checkboxes
    document.querySelectorAll('.filter').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            const category = e.target.dataset.category;
            if (e.target.checked) {
                activeFilters.add(category);
            } else {
                activeFilters.delete(category);
            }
            renderCalendar();
            renderMonthEvents();
        });
    });

    // Print button
    document.getElementById('printBtn').addEventListener('click', () => {
        window.print();
    });

    // Share button
    document.getElementById('shareBtn').addEventListener('click', shareEvents);

    // Reminder button
    document.getElementById('reminderBtn').addEventListener('click', showReminderModal);

    // Close modals
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });
}

function renderCalendar() {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                       'July', 'August', 'September', 'October', 'November', 'December'];
    
    document.getElementById('currentMonth').textContent = `${monthNames[currentMonth]} ${currentYear}`;

    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const prevLastDay = new Date(currentYear, currentMonth, 0);
    
    const firstDayIndex = firstDay.getDay();
    const lastDayDate = lastDay.getDate();
    const prevLastDayDate = prevLastDay.getDate();

    const calendarGrid = document.querySelector('.calendar-grid');
    
    // Keep weekday headers
    const weekdayHeaders = calendarGrid.querySelectorAll('.weekday');
    calendarGrid.innerHTML = '';
    weekdayHeaders.forEach(header => calendarGrid.appendChild(header));

    // Previous month days
    for (let i = firstDayIndex - 1; i >= 0; i--) {
        const day = createDayElement(prevLastDayDate - i, true);
        calendarGrid.appendChild(day);
    }

    // Current month days
    const today = new Date();
    for (let i = 1; i <= lastDayDate; i++) {
        const isToday = currentYear === today.getFullYear() && 
                       currentMonth === today.getMonth() && 
                       i === today.getDate();
        const day = createDayElement(i, false, isToday);
        calendarGrid.appendChild(day);
    }

    // Next month days to fill the grid
    const totalCells = firstDayIndex + lastDayDate;
    const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
    
    for (let i = 1; i <= remainingCells; i++) {
        const day = createDayElement(i, true);
        calendarGrid.appendChild(day);
    }
}

function createDayElement(dayNumber, isOtherMonth, isToday = false) {
    const dayDiv = document.createElement('div');
    dayDiv.className = 'day';
    
    if (isOtherMonth) {
        dayDiv.classList.add('other-month');
    }
    if (isToday) {
        dayDiv.classList.add('today');
    }

    const dayNumberDiv = document.createElement('div');
    dayNumberDiv.className = 'day-number';
    dayNumberDiv.textContent = dayNumber;
    dayDiv.appendChild(dayNumberDiv);

    // Add events for this day
    if (!isOtherMonth) {
        const dateString = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(dayNumber).padStart(2, '0')}`;
        const dayEvents = getEventsForDate(dateString);
        
        dayEvents.forEach(event => {
            if (activeFilters.has(event.category)) {
                const eventMarker = document.createElement('div');
                eventMarker.className = `event-marker ${event.category}`;
                eventMarker.textContent = `${categoryEmojis[event.category]} ${event.name}`;
                eventMarker.addEventListener('click', (e) => {
                    e.stopPropagation();
                    showEventDetail(event);
                });
                dayDiv.appendChild(eventMarker);
            }
        });
    }

    return dayDiv;
}

function getEventsForDate(dateString) {
    return events.filter(event => event.date === dateString);
}

function getEventsForMonth(month, year) {
    return events.filter(event => {
        const eventDate = new Date(event.date);
        return eventDate.getMonth() === month && eventDate.getFullYear() === year;
    }).sort((a, b) => new Date(a.date) - new Date(b.date));
}

function renderMonthEvents() {
    const monthEventsDiv = document.getElementById('monthEvents');
    const monthEvents = getEventsForMonth(currentMonth, currentYear);
    
    if (monthEvents.length === 0) {
        monthEventsDiv.innerHTML = '<p style="color: #666;">No events this month</p>';
        return;
    }

    monthEventsDiv.innerHTML = '';
    
    monthEvents.forEach(event => {
        if (activeFilters.has(event.category)) {
            const eventItem = document.createElement('div');
            eventItem.className = `event-item ${event.category}`;
            
            const eventDate = new Date(event.date);
            const formattedDate = eventDate.toLocaleDateString('en-US', { 
                weekday: 'short', 
                month: 'short', 
                day: 'numeric' 
            });
            
            eventItem.innerHTML = `
                <div class="event-name">${categoryEmojis[event.category]} ${event.name}</div>
                <div class="event-date">${formattedDate}</div>
            `;
            
            eventItem.addEventListener('click', () => showEventDetail(event));
            monthEventsDiv.appendChild(eventItem);
        }
    });
}

function showEventDetail(event) {
    const modal = document.getElementById('eventDetailModal');
    const eventDate = new Date(event.date);
    const formattedDate = eventDate.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric',
        month: 'long', 
        day: 'numeric' 
    });

    document.getElementById('eventTitle').textContent = `${categoryEmojis[event.category]} ${event.name}`;
    document.getElementById('eventDate').textContent = formattedDate;
    document.getElementById('eventDescription').textContent = event.description;
    
    const categoryBadge = document.createElement('span');
    categoryBadge.style.cssText = `
        display: inline-block;
        padding: 5px 15px;
        background: ${categoryColors[event.category]};
        color: white;
        border-radius: 15px;
        margin-top: 10px;
        font-size: 0.9em;
    `;
    categoryBadge.textContent = event.category.charAt(0).toUpperCase() + event.category.slice(1);
    
    const categoryDiv = document.getElementById('eventCategory');
    categoryDiv.innerHTML = '';
    categoryDiv.appendChild(categoryBadge);
    
    modal.style.display = 'block';
}

function shareEvents() {
    const monthEvents = getEventsForMonth(currentMonth, currentYear);
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                       'July', 'August', 'September', 'October', 'November', 'December'];
    
    let shareText = `📅 Calendar Events - ${monthNames[currentMonth]} ${currentYear}\n\n`;
    
    monthEvents.forEach(event => {
        if (activeFilters.has(event.category)) {
            const eventDate = new Date(event.date);
            const formattedDate = eventDate.toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric' 
            });
            shareText += `${categoryEmojis[event.category]} ${formattedDate}: ${event.name}\n`;
        }
    });

    if (navigator.share) {
        navigator.share({
            title: `Calendar ${monthNames[currentMonth]} ${currentYear}`,
            text: shareText
        }).catch(err => {
            console.log('Share failed:', err);
            copyToClipboard(shareText);
        });
    } else {
        copyToClipboard(shareText);
    }
}

function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    alert('Events copied to clipboard! You can now paste and share them.');
}

function showReminderModal() {
    const modal = document.getElementById('reminderModal');
    const reminderList = document.getElementById('reminderList');
    const reminders = getUpcomingReminders();
    
    if (reminders.length === 0) {
        reminderList.innerHTML = '<p style="color: #666; padding: 20px; text-align: center;">No upcoming reminders for the next 2 months</p>';
    } else {
        reminderList.innerHTML = '';
        reminders.forEach(reminder => {
            const reminderItem = document.createElement('div');
            reminderItem.className = `reminder-item ${reminder.category}`;
            if (reminder.daysUntil <= 30) {
                reminderItem.classList.add('urgent');
            }
            
            reminderItem.innerHTML = `
                <div style="font-weight: bold; margin-bottom: 5px;">
                    ${categoryEmojis[reminder.category]} ${reminder.name}
                </div>
                <div style="color: #666; font-size: 0.9em;">
                    ${reminder.dateFormatted}
                </div>
                <div style="margin-top: 5px; color: ${reminder.daysUntil <= 30 ? '#856404' : '#155724'}; font-weight: bold;">
                    ${reminder.daysUntil} days remaining
                </div>
            `;
            
            reminderList.appendChild(reminderItem);
        });
    }
    
    modal.style.display = 'block';
}

function checkAndShowReminders() {
    // Check if we should show automatic reminders (once per day)
    const lastCheck = localStorage.getItem('lastReminderCheck');
    const today = new Date().toDateString();
    
    if (lastCheck !== today) {
        const reminders = getUpcomingReminders().filter(r => r.daysUntil <= 60);
        if (reminders.length > 0) {
            localStorage.setItem('lastReminderCheck', today);
            // Show a subtle notification
            setTimeout(() => {
                const urgentReminders = reminders.filter(r => r.daysUntil <= 30);
                if (urgentReminders.length > 0) {
                    alert(`🔔 You have ${urgentReminders.length} event(s) coming up in the next month! Click "View Reminders" to see them.`);
                }
            }, 2000);
        }
    }
}
